package com.conwaygame.callbacks;

public interface ButtonListener {
	public void startClicked();
	public void resratClicked();
}
