package com.conwaygame.app;

import java.io.EOFException;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class App {

	public static void main(String[] args) { throws IOExeption, URISyntaxException {
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}	catch (ClassNotFoundException | InstantiationExeption
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new MainFrame();
			}
		});
		
	}

}
