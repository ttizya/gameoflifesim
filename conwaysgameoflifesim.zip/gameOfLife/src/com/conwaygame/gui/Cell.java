package com.conwaygame.gui;

import java.awt.Color;

public class Cell {

	public class Cell extends JPanel {
		
		private static final long serialVersionUID = 1L;
		private int id;
		private Board board;
		private boolean alive = false;
		
		public Cell(final int id, final board board) {
			this.id = id;
			this.board = board;
			
			initalizeLayout();
			initalizeListener(id);
		}
		
		private void initalizeListener(final int id) {
			addMouseListener(new MouseAdapter() {
				public void mousePresed(MouseEvent e) {
					setAlive(true);
					Cell.this.board.refreshBoard(id);
				}
			});
		}
		
		private void initalizedLayout() {
			setBorder(BorderFactory.createLineBorder(Color.BLACK));
			setBackground(Color.WHITE);
		}
		
		public boolean isAlive() {
			return alive;
		}
		
		public void setALive(boolean alive) {
			this.alive = alive;
		}
		
		public String toString() {
			return "Cell" + id;
		}

	}

}
